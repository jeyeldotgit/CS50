#include <cs50.h>
#include <time.h>
#include <stdio.h>

int main (void)
{

}