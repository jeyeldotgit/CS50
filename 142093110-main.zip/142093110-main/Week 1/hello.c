#include <stdio.h>
#include <cs50.h>

int main (void)
{
    string answer = get_string("Apple or Banana? ");
    printf("%s\n", answer);
}