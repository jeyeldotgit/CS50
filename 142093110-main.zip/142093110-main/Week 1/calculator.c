#include <cs50.h>
#include <stdio.h>

int main (void)
{
    //for the 1st number
    int x = get_int ("x: ");
    //for the 2nd number
    int y = get_int ("y: ");
    // Operation
    int n = get_int ("Operation: ");
    printf("%i\n", z);
}